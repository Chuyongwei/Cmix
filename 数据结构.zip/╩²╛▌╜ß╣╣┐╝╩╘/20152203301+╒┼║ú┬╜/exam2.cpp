#include<stdio.h>
#include<stdlib.h>
#define M 10

int min(int a[],int n){
	int b[n-1];
	if(n-1<0)
		return 0;
	if(a[0]>=a[n-1]){
		printf("Get %d\n",a[n-1]);
		a[0]=a[n-1];
		for(int i=0;i<n-1;i++)
			b[i]=a[i];
	}
	else{
		printf("Get %d\n",a[0]);
		for(int i=0;i<n-1;i++)
			b[i]=a[i];
	}
	min(b,n-1);
}
int main(){
	int a[M];
	printf("input 10 numbers:\n");
	for(int i=0;i<M;i++){
		scanf("%d",&a[i]);
	} 
	printf("������������һ��Ϊ��Сֵ��\n"); 
	min(a,M);
	return 0;
}
