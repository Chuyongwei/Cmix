#include<stdio.h>
#include<stdlib.h>
#define MAX 20

typedef struct BiTNode{
	char data;
	struct BiTNode *lchild,*rchild;
}BiTNode,*BiTree;

typedef struct{
	BiTree *base;
	int front,rear;
}CqQueue;

void CreateBiTree( BiTree &bt ){
	char ch;
	ch = getchar();
	if( ch == '#' ){
		bt = NULL;
	}
	else{
		bt = ( BiTree )malloc( sizeof( BiTNode ) );
		bt->data = ch;
		CreateBiTree( bt->lchild );
		CreateBiTree( bt->rchild );
	}
}

void InitQueue(CqQueue &Q){
//��ʼ��һ������
	Q.base=(BiTree*)malloc(MAX*sizeof(BiTree));
	Q.front=Q.rear=0;
}

int QueueEmpty(CqQueue Q){
//�ж϶����Ƿ�Ϊ��
	if(Q.front==Q.rear)
		return 1;
	return 0;
}

void EnQueue(CqQueue &Q,BiTree e){
//��Ӳ���
	if((Q.rear+1)%MAX==Q.front) //����
		return;
	Q.base[Q.rear]=e;
	Q.rear=(Q.rear+1)%MAX;
}

void DeQueue(CqQueue &Q,BiTree &e){
//���Ӳ���
	if(Q.rear ==Q.front) //�ӿ�
		return;
	e =Q.base[Q.front];
	Q.front=(Q.front+1)%MAX;
}

void CopyBiTree(BiTree bt,BiTree &bt1){
	if(bt!=NULL){
		bt1=(BiTree )malloc(sizeof(BiTree));
		bt1->data=bt->data;
		CopyBiTree(bt->lchild,bt1->lchild);
		CopyBiTree(bt->rchild,bt1->rchild);
	}
	else
		bt1=NULL;
}
void PreOrderTraverse1( BiTree bt )
{//����������������ݹ�
	if( bt )
	{
		printf( "%c\t",bt->data );
		PreOrderTraverse1( bt->lchild );
		PreOrderTraverse1( bt->rchild );
	}
}
int main(){
	BiTree bt,bt1;
	printf("input strings to creat bitree(# to stop):\n");
	CreateBiTree(bt);
	printf("copy bt to bt1:\n");
	CopyBiTree(bt,bt1);
	printf("Success!!\n");
	PreOrderTraverse1(bt1);
	return 0;
}
