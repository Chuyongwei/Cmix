#include<stdio.h>
#include<stdlib.h>
#include<time.h>

typedef struct LNode{
	int data;
	struct LNode *next;
}LNode,*LinkList;

void createList(LinkList &L){
	int i,n;
	LinkList p;
	srand(time(0));
	L=(LinkList)malloc(sizeof(LNode));
	L->next=L;
	printf("input the numbers you want��");
	scanf("%d",&n); 
	for(i=n;i>=0;--i){
		p=(LinkList)malloc(sizeof(LNode));
		p->data=rand()%90+10;
		p->next=L->next;
		L->next=p;
	}
}

void Reverse(LinkList &L,int i,int j){
	int m;
	LinkList p,q,o,r,s;
	p=L->next;
	q=L->next;
	s=L;
	for(m=1;m<i;m++)
		s=s->next;
	for(m=1;m<i;m++)
		p=p->next;
	for(m=0;m<j;m++)
		q=q->next;
	o=q;
	while(p!=o){
		r=q;
		q=p;
		p=p->next;
		q->next=r;
	}
	s->next=q;
}

void ListTraverse(LinkList L){
	LinkList p=L->next;
	while(p->next!=L){
		printf("%d  ",p->data);
		p=p->next;
	}
	printf("\n");
}

int main()
{
	int i,j;
	LinkList L;
	createList(L);
	ListTraverse(L);
	printf("\n");
	printf("input the area of i and j to Reverse:\n");
	scanf("%d%d",&i,&j);
	Reverse(L,i,j);
	printf("Reversed:\n");
	ListTraverse(L);
	return 0;
}
