#include <stdio.h>
#define MaxNum 10000
BinTree buildTree(elementype BT[],int i,int n){
	BinTree r;
	if(i>n)
		return NULL;
	r=(BinTree *)malloc(sizeof(BinNode));
	r->data=BT[i];
	r->Lchild=buildTree(BT,2*i,n);
	r->Rchild=buildTree(BT,2*i+1,n);
	return r;
}
int checkTree(BinTree t)
{
  	int maxn0=0;
	n=num(t,1,&maxn0);
	if(n==maxn0)
		return 1;
   	else
     	return 0;
}
int num(BinTree t,int i,int *m)
{
  	if(t==NULL)
     	return 0;
  	if(*m<i)
		*m=i;
	return (1+num(t->Lchild,2*i,m)+num(t->Rchild,2*i+1,m));
}
int main( )
{
  	int data,t,i,*m;
  	printf("input data:\n")
  	scanf("%d,&data");
	if(t==NULL)
		printf("F\n");
	if(*m<i)
		*m=i;
	printf("T\n");
	return 0;
}
