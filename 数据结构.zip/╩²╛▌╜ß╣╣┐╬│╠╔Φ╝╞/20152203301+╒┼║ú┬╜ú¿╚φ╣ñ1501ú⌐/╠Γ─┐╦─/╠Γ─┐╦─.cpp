#include<stdio.h>
#include<string.h>
#include<stdlib.h> 
int e[1111][1111], dis[1111];
bool book[1111];
const int inf = 999999999;
void Dijkstra(char s, int m, int n)
{
    int i, j, min, u, v;
    for (i = 1; i <= n; i++)
    {
        book[i] = 0;
        dis[i] = e[s][i];
    }
    book[s] = 1;
    for (i = 1; i < n - 1; i++)
    {
        min = inf;
        for (j = 1; j <= n; j++)
        {
            if (!book[j] && dis[j] < min)
            {
                min = dis[j];
                u = j;
            }
        }
        book[u] = 1;
        for (v = 1; v <= n; v++)
            if (e[u][v] < inf && dis[v] > dis[u] + e[u][v])
                dis[v] = dis[u] + e[u][v];
    }
}
int main()
{
    int n, m, t, u, v, s, i;
    int inf = 999999999;
    printf("�����붥�����:");
    scanf("%d",&n);
    printf("������ߵ�����:");
    scanf("%d",&m);
    for (i = 1; i <= m; i++)
    {
        printf("�������%d���ߵ���㡢�յ㡢����Ȩֵ:",i);
        scanf("%d%d%d",&u,&v,&t);
        e[u][v] = t;
    }
    printf("���������:");
    scanf("%d",&s);
    Dijkstra(s, m, n);
    for (i = 1; i <= n; i++)
       printf("��%d��%d����̾���Ϊ:%d\n",s,i,dis[i]);
    return 0;
}
