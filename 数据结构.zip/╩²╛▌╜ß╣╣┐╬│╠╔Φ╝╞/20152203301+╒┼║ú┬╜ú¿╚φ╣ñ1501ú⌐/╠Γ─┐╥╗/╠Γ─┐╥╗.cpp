#include<stdio.h>
#include<string.h>
#include<stdlib.h>

typedef struct{
 	char num[10];
 	char name[20];
 	char phone[13];
 	char addr[20];
}datatype;

typedef struct node{
 	datatype data;
 	struct node * next;
}listnode;

typedef listnode * linklist;
linklist head;
listnode *p;

int menu_select()
{//ͨѶ¼����ϵͳ 
 	int sn;
 	printf("   \n");
 	printf("  \n");
 	printf(" \n");
 	printf("                               ͨѶ¼����ϵͳ   \n");
	printf(" \n");
	printf("                          ======================\n");
	printf("                           1.ͨѶ¼�����Ľ���\n");
	printf("                           2.ͨѶ�߽��Ĳ���\n");
	printf("                           3.ͨѶ¼�����Ĳ�ѯ\n");
	printf("                           4.ͨѶ�߽���ɾ��\n");
	printf("                           5.ͨѶ¼���������\n");
	printf("                           0.�˳�ͨѶ¼����ϵͳ\n");
	printf("                          ======================\n");
	printf( "                            ��ѡ�����(0-5) \n\n");
	for(; ;)
	{
  		scanf("%d",&sn);
 		if(sn<0||sn>5)
   			printf("\t�������\n");
  		else 
   			break;
 	}
 	return sn;
}

linklist createlist(void)
{//����ͨѶ¼���� 
 	linklist head=(listnode *)malloc(sizeof(listnode));
    	listnode *p,*rear;
   	int flag=1;
    	rear=head;
    	while(flag==1)
	{
  		p=(listnode *)malloc(sizeof(listnode));
    		printf(" ���(4) ����(20) �绰(13) ��ַ(20) \n");
     		printf(" --------------------------------------------\n");
        		scanf("%s%s%s%s",p->data.num,p->data.name,p->data.phone,p->data.addr);
        		rear->next=p;
        		rear=p;
        		printf(" ���������� (1.��/0.��):");
        		scanf("%d",&flag);
   	}
 	if(flag==1)
   		printf("�����ɹ�!\n");
    	rear->next=NULL;
    	return head; 
}

void insertnode(linklist head,listnode *p)
{//ͨѶ�ߵĲ��� 
 	listnode *p1,*p2;
 	p1=head;
 	p2=p1->next;
 	while(p2!=NULL && strcmp(p2->data.num,p->data.num)<0)
 	{
  		p1=p2;
  		p2=p2->next;
	}
 	p1->next=p;
 	p->next=p2;
 	printf("����ɹ���\n");
}

listnode * listfind(linklist head)
{//ͨѶ�ߵĲ��� 
 	listnode * p;
 	char num[6];
 	char name[10];
	int xz;
 	printf("--------------------\n");
 	printf(" 1.��Ų�ѯ\n");
 	printf(" 2.������ѯ\n"); 
 	printf("--------------------\n");
 	printf("��ѡ��: \n");
 	p=head->next;
 	scanf("%d",&xz);
 	if(xz==1)
	{
  		printf(" ������Ҫ���ҵı�ţ� ");
     		scanf("%s",num);
     		while(p && strcmp(p->data.num,num)<0)
  			p=p->next;
     		if (p==NULL || strcmp(p->data.num,num)>0)
      			p=NULL;
	}
 	else 
	{
     		if(xz=2)
		{
      			printf("������Ҫ��ѯ�ߵ�����: ");
      			scanf("%s",name);
      			while(p && strcmp(p->data.name,name)!=0)
       				p=p->next;
     		}
	}
 	return p;
}

void delnode(linklist head)
{//ͨѶ�ߵ�ɾ�� 
    	int jx;
    	listnode *p,*q;
    	p=listfind(head);
    	if(p==NULL)
	{
     		printf("û��Ҫɾ����ͨѶ��!:\n");
     		return;
    	}
    	printf ("���Ҫɾ���ý����(1.��/0.��):");
    	scanf("%d",&jx);
   	if (jx==1)
	{
     		q=head;
     		while(q!=NULL && q->next!=p)
      			q=q->next;
     		q->next=p->next;
     		free(p);
     		printf("ͨѶ���ѱ�ɾ��!\n");
    	}
}

void printlist(linklist head)
{//ͨѶ�ߵ���� 
 	listnode * p;
    	p=head->next;
    	printf(" ���  ����  �绰  ��ַ\n");
 	printf(" -----------------------------\n");
    	while(p!=NULL)
 	{
   		printf("%s\t %s\t %s\t %s\t\n",p->data.num,p->data.name,p->data.phone,p->data.addr);
      		printf(" ------------------------------\n");
   		p=p->next;
 	}

}

int main()
{
 	for( ; ; )
	{
  		switch(menu_select())
		{
  			case 1:
			{
				printf(" ***********************************************\n");
   				printf(" ************** ͨѶ¼�����Ľ��� ***************\n");
    				printf(" ***********************************************\n");
   				head=createlist();
   				break;
  			}
			case 2:
			{
				printf(" ***********************************************\n");
   				printf(" ************** ͨѶ¼��Ϣ���� *****************\n");
        				printf(" ***********************************************\n");
   				printf(" *******���(4)*����(20)*�绰(13)*��ַ(20)*******\n");
   				printf(" ***********************************************\n");
   				p=(listnode *)malloc(sizeof(listnode));
   				scanf("%s%s%s%s",p->data.num,p->data.name,p->data.phone,p->data.addr);
   				insertnode(head,p);
   				break;
   			} 
  			case 3:
			{
				printf(" ******************************\n");
   				printf(" ******* ͨѶ¼��Ϣ��ѯ *******\n");
        				printf(" ******************************\n");
   				p=listfind(head);
   				if(p!=NULL)
				{
   					printf(" ** ���  ����  �绰 ��ַ**\n");
   					printf(" ------------------------------\n");
   					printf("%s,%s,%s,%s\n",p->data.num,p->data.name,p->data.phone,p->data.addr);
      					printf(" ------------------------------\n");
   				}
   				else
    					printf("û����Ҫ�ҵ��� ! \n");
   				break;
   			} 
   			case 4:
			{
				printf(" ***********************************\n");
    	   			printf(" **********ͨѶ��Ϣ��ɾ��***********\n");
     	   			printf(" ***********************************\n");
    				delnode(head);
    				break;
    			} 
  			case 5:
			{
				printf(" ***********************************\n");
     	   			printf(" **********ͨѶ¼���������*********\n");
     	   			printf(" ***********************************\n"); 
    				printlist(head);
    				break;
    			} 
  			case 0:printf("\t лл����ʹ�ã� \n");break;
  		}
 	}
 	return 0;
}
