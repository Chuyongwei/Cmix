#include<stdio.h>
#include<stdlib.h>

typedef struct Node
{
	int data;
	struct Node *pnext;
}NODE;

NODE* CreateList()
{
	int length;
	int i;
	int num;

	NODE* phead=(NODE*)malloc(sizeof(NODE));
	NODE* ptail=phead;
	ptail->pnext=NULL; 
	
	printf("������Ҫ���ɵ������нڵ�ĸ�����");
	scanf("%d",&length);
	printf("�밴��С�����˳�����롣\n") ;

	for(i=0;i<length;i++)
	{
		printf("�������%d���ڵ��ֵ��",i+1);
		scanf("%d",&num);

		NODE* pnew=(NODE*)malloc(sizeof(NODE));

		pnew->data=num;
		ptail->pnext=pnew;
		pnew->pnext=NULL;
		ptail=pnew;
	}
	return phead;
}

NODE* Combine(NODE* head1,NODE* head2)
{
	if(head1==NULL||head1->pnext==NULL)
	{
		return head2;
	}
	if(head2==NULL||head2->pnext==NULL)
	{
		return head1;
	}
	NODE* head;
	head=(NODE*)malloc(sizeof(NODE));
	head->pnext=NULL;
	NODE* pnew;
	NODE* ptail;
	NODE* p1=head1->pnext;
	NODE* p2=head2->pnext;
	ptail=head;
	while(p1!=NULL&&p2!=NULL)
	{
		if(p1->data<p2->data)
		{
			pnew=(NODE*)malloc(sizeof(NODE));
			pnew->data=p1->data;
			pnew->pnext=NULL;
			ptail->pnext=pnew;
			ptail=ptail->pnext;
			p1=p1->pnext;
		}
		else if(p1->data>p2->data)
		{
			pnew=(NODE*)malloc(sizeof(NODE));
			pnew->data=p2->data;
			pnew->pnext=NULL;
			ptail->pnext=pnew;
			ptail=ptail->pnext;
			p2=p2->pnext;
		}
		else
		{
			pnew=(NODE*)malloc(sizeof(NODE));
			pnew->data=p1->data;
			pnew->pnext=NULL;
			ptail->pnext=pnew;
			ptail=ptail->pnext;
			p1=p1->pnext;
			p2=p2->pnext;
		}
	}

	if(p1!=NULL)
	{
		while(p1!=NULL)
		{
			pnew=(NODE*)malloc(sizeof(NODE));
			pnew->data=p1->data;
			pnew->pnext=NULL;
			ptail->pnext=pnew;
			ptail=ptail->pnext;
			p1=p1->pnext;
		}
	}
	if(p2!=NULL)
	{
		while(p2!=NULL)
		{
			pnew=(NODE*)malloc(sizeof(NODE));
			pnew->data=p2->data;
			pnew->pnext=NULL;
			ptail->pnext=pnew;
			ptail=ptail->pnext;
			p2=p2->pnext;
		}
	}
	return head;
}

void TraverseList(NODE* phead)
{
	NODE* p=phead->pnext;
	
	while(p!=NULL)
	{
		printf("%d ",p->data);
		p=p->pnext;
	}
	printf("\n");
}


int main()
{
	NODE* La=NULL;
	NODE* Lb=NULL;
	NODE* Lc=NULL;
	printf("��������La��\n");
	La=CreateList();
	printf("\n��������Lb��\n");
	Lb=CreateList();
	Lc=Combine(La,Lb);
	printf("\n�ϲ�La��LbΪLc��");
	TraverseList(Lc);

	return 0;
}
