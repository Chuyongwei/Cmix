#include<stdio.h>
#include<stdlib.h>
#include<malloc.h>

typedef struct PolynNode
{
	int coef;
	int expn;
	struct PolynNode* pnext;
}LIST;


void CreatePolyn(LIST* &L,int n)
{
	int i;
	LIST* pnew;
	LIST* ptail;
	L=(LIST*)malloc(sizeof(LIST)); 
	L->pnext=NULL;
	ptail=L;
	printf("�밴ָ�����С�����˳��ɶ�����ö���ʽ��%d������\n",n);
	for(i=1;i<=n;i++)
	{
		pnew=(LIST*)malloc(sizeof(LIST));
		scanf("%d%d",&pnew->coef,&pnew->expn);
		ptail->pnext=pnew;
		ptail=ptail->pnext;
	} 
	pnew->pnext=NULL;
}

LIST* DerivationList(LIST* L)
{
	LIST* Head;
	LIST* pnew;
	LIST* ptail;
	LIST* p;
	
	p=L;
	Head=(LIST*)malloc(sizeof(LIST));
	Head->coef=0;
	Head->expn=0;
	Head->pnext=NULL;
	ptail=Head;
	p=p->pnext;
	
	while(p!=NULL)
	{
		if((p->expn)==0)
			p=p->pnext;
		else
		{
		
			pnew=(LIST*)malloc(sizeof(LIST));
			ptail->pnext=pnew;
			pnew->coef=(p->coef)*(p->expn);
			pnew->expn=(p->expn)-1;
			pnew->pnext=NULL;
			p=p->pnext;
			ptail=ptail->pnext;	
		}
	}
	return Head;
}

void TraverseList(LIST* L)
{
	LIST* p=L->pnext;

	while(p!=NULL)
	{
		printf("%dX^%d  ",p->coef,p->expn);
		p=p->pnext;
	}
	printf("\n");
}

int main()
{
	int num;
	LIST* La=NULL;
	LIST* Lb=NULL;
	printf("�������һԪ����ʽ��������");
	scanf("%d",&num); 
	CreatePolyn(La,num);
	printf("�ö���ʽ�ĸ���Ϊ��");
	TraverseList(La);
	Lb=DerivationList(La);
	printf("�󵼺��һԪ����ʽ�ĸ���Ϊ��");
	TraverseList(Lb);
	return 0;
}

