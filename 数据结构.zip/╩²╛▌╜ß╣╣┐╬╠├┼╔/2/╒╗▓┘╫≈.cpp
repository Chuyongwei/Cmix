#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <stdlib.h>
char ss[1000000];
int len;
struct node{
    char c;
    struct node *next;
};
struct node *creat1(char *s){
    struct node *head,*tail,*p;
    head=(struct node *)malloc(sizeof(struct node ));
    head->next=NULL;
    tail=head;
    int i;
    for(i=0;s[i]!='\0';i++){
        p=(struct node *)malloc(sizeof(struct node));
        p->c=s[i];
        tail->next=p;
        p->next=NULL;
        tail=p;
    }
    return head;
};
struct node *creat2(char *s){
    struct node *head,*tail,*p;
    head=(struct node *)malloc(sizeof(struct node ));
    head->next=NULL;
    tail=head;
    int i;
    int len=strlen(s);
    for(i=len-1;i>=0;i--){
        p=(struct node *)malloc(sizeof(struct node));
        p->c=s[i];
        tail->next=p;
        p->next=NULL;
        tail=p;
    }
    return head;
};
int main(){
    char s[10000];
    while(~scanf("%s",s)){
        struct node *head1,*head2;
        head1=(struct node *)malloc(sizeof(struct node ));
        head2=(struct node *)malloc(sizeof(struct node ));
        head1->next=NULL;
        head2->next=NULL;
        head1=creat1(s);
        head2=creat2(s);
        int flag=0;
        struct node *p,*q;
        p=head1->next;
        q=head2->next;
        while(p!=NULL){
            if(p->c!=q->c){
                flag=1;
                break;
            }
            p=p->next;
            q=q->next;
        }
        if(flag){
            printf("NO\n");
        }
        else{
            printf("YES\n");
        }
    }
    return 0;
}
